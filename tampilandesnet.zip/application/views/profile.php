<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Admin Dashboard
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <section class="content">
      <h1><a href="<?= base_url('profile') ?>">Tampilan Admin</h1>
      <h1><a href="<?= base_url('pengguna') ?>">Tampilan Pengguna</h1>
  </section> 
    <!-- /.content -->
  </div>